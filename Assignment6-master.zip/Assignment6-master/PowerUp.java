package edu.nyu.cs;

public class PowerUp {

}
