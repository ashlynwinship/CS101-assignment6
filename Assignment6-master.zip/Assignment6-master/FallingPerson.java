package edu.nyu.cs;

public class FallingPerson {

}
