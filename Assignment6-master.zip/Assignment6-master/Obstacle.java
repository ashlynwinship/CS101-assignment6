package edu.nyu.cs;

public class Obstacle {

}
